/*
*	Name : Siddharth Singh
*   Unity Id : ssingh29
*
*/

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <stack>
#include <deque>
#include <algorithm>
#include <functional>
#include <cstring>

std::string CityRoadMap[] = 
{
	"oradea zerind",  
	"arad timisoara", 
	"lugoj mehadia",  
	"oradea sibiu",
	"dobreta craiova",  
	"sibiu fagaras",  
	"pitesti craiova",  
	"bucharest pitesti", 
	"bucharest giurgiu",  
	"vaslui urziceni",  
	"hirsova eforie",  
	"neamt iasi",
	"zerind arad",
	"timisoara lugoj",
	"dobreta mehadia",
	"arad sibiu",
	"sibiu rimnicu_vilcea",
	"rimnicu_vilcea craiova",
	"rimnicu_vilcea pitesti",
	"bucharest fagaras",
	"bucharest urziceni",
	"hirsova urziceni",
	"vaslui iasi"
};

struct Node
{
	std::string cityName;
	bool visited;
	std::vector<Node*> adjacentNodes;
	Node *parent;
	Node(const std::string& city,bool isVisited):visited(isVisited),cityName(city),parent(0){} 
};

Node* getNode(std::map<std::string,Node*> &RoadMap,const std::string &city)
{
	std::map<std::string,Node*>::iterator it = RoadMap.lower_bound(city);
	if(it != RoadMap.end() && !(RoadMap.key_comp()(city, it->first)))
	{
		return it->second;
	}
	else
	{
		Node *node = new Node(city,false);
		RoadMap.insert(it,std::map<std::string,Node*>::value_type(city, node));    
		return node;
	}
}

Node* findNode(std::map<std::string,Node*> &RoadMap,const std::string &city)
{
	std::map<std::string,Node*>::iterator it = RoadMap.find(city);
	if(it == RoadMap.end())
	{
		return 0;
	}
	else
	{
		return it->second;
	}
}


void createGraph(std::map<std::string,Node*> &RoadMap)
{
	int edges = (sizeof(CityRoadMap)/sizeof(std::string));	
	for(int i = 0;i < edges; ++i)
	{
		std::stringstream ss;
		ss<<CityRoadMap[i];
		std::string city1,city2;
		ss>>city1;
		ss>>city2;
		Node *city1Node = getNode(RoadMap,city1);
		Node *city2Node = getNode(RoadMap,city2);
		city1Node->adjacentNodes.push_back(city2Node);
		city2Node->adjacentNodes.push_back(city1Node);
	}
}

void printGraph(std::map<std::string,Node*> &RoadMap)
{
	std::map<std::string,Node*>::const_iterator it = RoadMap.begin();
	for(; it != RoadMap.end(); ++it)
	{
		std::cout<<it->first<<":";
		std::vector<Node*> nodes = (it->second)->adjacentNodes;
		std::vector<Node*>::iterator vit = nodes.begin();
		for(; vit != nodes.end(); ++vit)
		{
			std::cout<<(*vit)->cityName<<",";
		}
		std::cout<<nodes.size()<<"\n";
	}
}

void printPath(Node* node)
{
	if(node)
	{
		printPath(node->parent);
		if(node->parent)
		{
			std::cout<<"->";
		}
		std::cout<<node->cityName;
	}
}

bool greater(const Node* node1, const Node* node2)
{
	return std::greater<std::string>()(node1->cityName,node2->cityName);
}

std::vector<Node*> moveGenerator(Node *parent)
{
	std::vector<Node*> temp = parent->adjacentNodes;
	std::sort (temp.begin(), temp.end(), greater);
	return temp;
}


bool DFS(std::map<std::string,Node*> &RoadMap,const std::string &source,const std::string &goal)
{
	std::stack<Node*> dfsStack;
	std::vector<Node*> expandedNodes;
	Node* sourceNode = findNode(RoadMap,source);
	if(!sourceNode)
	{
		std::cout<<"Start City name not found\n";
		return false;
	}
	sourceNode->visited = true;
	dfsStack.push(sourceNode);
	while(!dfsStack.empty())
	{
		Node* topNode = dfsStack.top();
		dfsStack.pop();//expanded
		expandedNodes.push_back(topNode);
		/*Do Goal Match*/
		if(topNode->cityName == goal)
		{
			printPath(topNode);
			return true;
		}
		std::vector<Node*> adjacentNodes = moveGenerator(topNode);//replace with move generator
		std::vector<Node*>::iterator vit = adjacentNodes.begin();
		for(; vit != adjacentNodes.end(); ++vit)
		{
			if(!((*vit)->visited))
			{
				(*vit)->visited = true;//visited
				(*vit)->parent = topNode;
				dfsStack.push(*vit);
			}
		}
	}
	//not found
	std::cout<<"Destination City name not found\n";
	return false;
}


bool BFS(std::map<std::string,Node*> &RoadMap,const std::string &source,const std::string &goal)
{
	std::deque<Node*> bfsQueue;
	std::vector<Node*> expandedNodes;
	Node* sourceNode = findNode(RoadMap,source);
	if(!sourceNode)
	{
		std::cout<<"Start City name not found\n";
		return false;
	}
	sourceNode->visited = true;
	bfsQueue.push_back(sourceNode);
	while(!bfsQueue.empty())
	{
		Node* topNode = bfsQueue.front();
		bfsQueue.pop_front();//expanded
		expandedNodes.push_back(topNode);
		/*Do Goal Match*/
		if(topNode->cityName == goal)
		{
			printPath(topNode);
			return true;
		}
		std::vector<Node*> adjacentNodes = moveGenerator(topNode);//replace with move generator
		std::vector<Node*>::iterator vit = adjacentNodes.begin();
		for(; vit != adjacentNodes.end(); ++vit)
		{
			if(!((*vit)->visited))
			{
				(*vit)->visited = true;//visited
				(*vit)->parent = topNode;
				bfsQueue.push_back(*vit);
			}
		}
	}
	//not found
	std::cout<<"Destination City name not found\n";
	return false;
}



int main(int argc, char* argv[])
{
	if (argc < 4) 
	{
		std::cout << "Usage : ./a.out [dfs|bfs] [start] [destination]\n";
		return 1;
	} 
	std::string startCity = argv[2];
	std::string destinationCity = argv[3];
	bool isDfs = false;
	if (strcmp(argv[1], "dfs")==0) 
	{
		isDfs = true;
    } 
	else if (strcmp(argv[1], "bfs")==0) 
	{  
    }
	else
	{
		std::cout << "Unknown Search Type\n";
		std::cout << "Usage : ./a.out [dfs|bfs] [start] [destination]\n";
		return 1;
	}
	std::map<std::string,Node*> RoadMap;
	createGraph(RoadMap);
	std::cout << "\n";
	isDfs ? DFS(RoadMap,startCity,destinationCity) : BFS(RoadMap,startCity,destinationCity);
	std::cout << "\n";
	return 0;
}
