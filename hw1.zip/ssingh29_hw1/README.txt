/*
*   Name : Siddharth Singh
*   Unity Id : ssingh29
*
*/


Build:
-------
g++ SearchRomania.cpp

Run :
-----
./a.out [dfs|bfs] [start] [destination]