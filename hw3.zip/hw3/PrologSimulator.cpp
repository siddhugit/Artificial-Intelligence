#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <functional> 
#include <cctype>
#include <locale>

using namespace std;

static const string WHITESPACES = " \f\n\r\t\v";
static const string ISA = "isa";
static const string AKO = "ako";
static const string CONTAINS = "contains";
static const string SHOULD_AVOID = "shouldAvoid";
static const string DAVID = "david";
static const string DIABETICS = "diabetics";
static const string SUGAR = "sugar";
static const string CANDY = "candy";
static const string SNICKERS = "snickers";

struct Edge
{
	string m_from;
	string m_to;
	string m_type;
	Edge(string from,string type,string to):m_from(from),m_to(to),m_type(type){}
	bool operator==(const Edge& other)const
	{
		return (other.m_from == m_from && other.m_type == m_type && other.m_to == m_to);
	}
};

static vector<string> Nodes;
static vector<string> Slots;
static vector<Edge> Edges;

static void initGraph()
{
	Nodes.push_back(DAVID);
	Nodes.push_back(DIABETICS);
	Nodes.push_back(SUGAR);
	Nodes.push_back(CANDY);
	Nodes.push_back(SNICKERS);
	Slots.push_back(SHOULD_AVOID);
	Slots.push_back(CONTAINS);
	Slots.push_back(ISA);
	Slots.push_back(AKO);
	Edges.push_back(Edge(DAVID,ISA,DIABETICS));
	Edges.push_back(Edge(DIABETICS,SHOULD_AVOID,SUGAR));
	Edges.push_back(Edge(CANDY,CONTAINS,SUGAR));
	Edges.push_back(Edge(SNICKERS,AKO,CANDY));
}

static bool edgeExists(Edge edge)
{
	return (find(Edges.begin(),Edges.end(),edge) != Edges.end());
}

static vector<Edge> createImplicitEdge(string node, string slot, string value) 
{
	vector<Edge> result;
	Edge tempEdge(node, slot, value);
	if(edgeExists(tempEdge)) 
	{
		result.push_back(tempEdge);
		return result;
	}
	for(unsigned int i = 0;i < Nodes.size();++i)
	{
		Edge edge(node, ISA, Nodes[i]);
		if(edgeExists(edge)) 
		{
			vector<Edge> ret = createImplicitEdge(Nodes[i], slot, value);
			if(!ret.empty()) 
			{
				result.push_back(tempEdge);
				return result;
			}
		}
	}
	for(unsigned int i = 0;i < Nodes.size();++i)
	{
		Edge edge(node, AKO, Nodes[i]);
		if(edgeExists(edge)) 
		{
			vector<Edge> ret = createImplicitEdge(Nodes[i], slot, value);
			if(!ret.empty()) 
			{
				result.push_back(tempEdge);
				return result;
			}
		}
	}
	if(SHOULD_AVOID == slot) 
	{
		for(unsigned int i = 0;i < Nodes.size();++i) 
		{
			vector<Edge> ret = createImplicitEdge(value, CONTAINS, Nodes[i]);
			if(!ret.empty()) {
				vector<Edge> ret2 = createImplicitEdge(node, SHOULD_AVOID, Nodes[i]);
				if(!ret2.empty()) {
					result.push_back(tempEdge);
					return result;
				}
			}
		}
	}
	return result;
}

static bool isConst(string node)
{
	return (node[0] == tolower(node[0]));
}

static vector<string> getNodes(string node)
{
	vector<string> ret = (isConst(node) ? vector<string>(1,node): Nodes);
	return ret;
}

static vector<string> getSlots(string slot)
{
	vector<string> ret = (isConst(slot) ? vector<string>(1,slot): Slots);
	return ret;
}

static vector<Edge> fillValue(string node,string slot,string value)
{
	vector<Edge> result;
	vector<string> iter1 = getNodes(node);
	vector<string> iter2 = getSlots(slot);
	vector<string> iter3 = getNodes(value);
	for(unsigned int i = 0;i < iter1.size();++i) 
	{
		for(unsigned int j = 0;j < iter2.size();++j) 
		{
			for(unsigned int k = 0;k < iter3.size();++k) 
			{
				vector<Edge> ret = createImplicitEdge(iter1[i],iter2[j],iter3[k]);
				if(!ret.empty()) 
				{
					result.push_back(Edge(iter1[i],iter2[j],iter3[k]));
				}
			}
		}
	}
	return result;
}

static vector<Edge> fillEdge(string node,string slot,string value)
{
	vector<Edge> result;
	vector<string> iter1 = getNodes(node);
	vector<string> iter2 = getSlots(slot);
	vector<string> iter3 = getNodes(value);
	for(unsigned int i = 0;i < iter1.size();++i) 
	{
		for(unsigned int j = 0;j < iter2.size();++j) 
		{
			for(unsigned int k = 0;k < iter3.size();++k) 
			{
				Edge edge(iter1[i],iter2[j],iter3[k]);
				if(edgeExists(edge)) 
				{
					result.push_back(edge);
				}
			}
		}
	}
	return result;
}

static string trim_right_copy(const std::string& str)
{
  return str.substr( 0, str.find_last_not_of( WHITESPACES ) + 1 );
}

static string trim_left_copy(const std::string& str)
{
  return str.substr( str.find_first_not_of( WHITESPACES ) );
}

static string trim_copy(const std::string& str)
{
  return trim_left_copy( trim_right_copy(str));
}

static vector<string> getTokens(const string& query)
{
	vector<string> result;
	string delim = ",";
	int start = query.find("(") + 1;
    int end = query.find(delim);
    while (end != std::string::npos)
    {
		result.push_back(trim_copy(query.substr(start, end - start)));
        start = end + delim.length();
        end = query.find(delim, start);
    }
	end = query.find(")");
    result.push_back(trim_copy(query.substr(start, end - start)));
	return result;
}

static void printReport(const vector<Edge>& result,const vector<string>& tokens)
{
	if(!result.empty() && isConst(tokens[0]) && isConst(tokens[1]) && isConst(tokens[2]))
	{
		cout<<"true\n";
	}
	else if(!result.empty())
	{
		vector<Edge>::const_iterator it  = result.begin();
		for(; it != result.end(); ++it)
		{
			cout<<tokens[0]<<" : "<<it->m_from<<"\n";
			cout<<tokens[1]<<" : "<<it->m_type<<"\n";
			cout<<tokens[2]<<" : "<<it->m_to<<"\n";
			cout<<"\n";
		}
		cout<<"false\n";
	}
	else
	{
		cout<<"false\n";
	}
}

int main()
{
	initGraph();
	string query;
	cout<<"Enter a query or type exit : ";
	getline (cin, query);
	while(query != "exit")
	{
		string queryType = trim_copy(query.substr(0, query.find("(")));
		vector<string> tokens = getTokens(query);
		vector<Edge> result;
		if(queryType == "value")
		{
			result = fillValue(tokens[0],tokens[1],tokens[2]);
		}
		if(queryType == "edge")
		{
			result = fillEdge(tokens[0],tokens[1],tokens[2]);
		}
		printReport(result,tokens);
		cout<<"Enter a query or type exit : ";
		getline (cin, query);
	}
	return 0;
}
