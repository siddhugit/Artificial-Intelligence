/*
*	Name : Siddharth Singh
*   Unity Id : ssingh29
*
*/

#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <queue>
#include <algorithm>
#include <functional>
#include <cstring>
#include <limits>
#include <cmath>

static const double PI_VAL = 3.1415926535897;
static const int SENTINEL_VAL = std::numeric_limits<int>::max();
std::vector<std::string> CityRoadMap; 

std::string getEdgeStr(const std::string& src,const std::string& dest,int dist)
{
	std::stringstream ss;
	ss<<src<<" "<<dest<<" "<<dist;
	return ss.str();
}

struct Location
{
	double latitude;
	double longitude;
};

std::map<std::string,Location> locationMap;

std::pair<std::string,Location> getLocation(std::string city,double latitude,double longitude)
{
	Location loc;
	loc.latitude = latitude;
	loc.longitude = longitude;
	return std::make_pair(city,loc);
}

void initLocations()
{
	locationMap.insert(getLocation("albanyGA",31.58,84.17));
	locationMap.insert(getLocation("albanyNY",42.66,73.78));
	locationMap.insert(getLocation("albuquerque",35.11,106.61));
	locationMap.insert(getLocation("atlanta",33.76,84.40));
	locationMap.insert(getLocation("augusta",33.43,82.02));
	locationMap.insert(getLocation("austin",30.30,97.75));
	locationMap.insert(getLocation("bakersfield",35.36,119.03));
	locationMap.insert(getLocation("baltimore",39.31,76.62));
	locationMap.insert(getLocation("batonRouge",30.46,91.14));
	locationMap.insert(getLocation("beaumont",30.08,94.13));
	locationMap.insert(getLocation("boise",43.61,116.24));
	locationMap.insert(getLocation("boston",42.32,71.09));
	locationMap.insert(getLocation("buffalo",42.90,78.85));
	locationMap.insert(getLocation("calgary",51.00,114.00));
	locationMap.insert(getLocation("charlotte",35.21,80.83));
	locationMap.insert(getLocation("chattanooga",35.05,85.27));
	locationMap.insert(getLocation("chicago",41.84,87.68));
	locationMap.insert(getLocation("cincinnati",39.14,84.50));
	locationMap.insert(getLocation("cleveland",41.48,81.67));
	locationMap.insert(getLocation("coloradoSprings",38.86,104.79));
	locationMap.insert(getLocation("columbus",39.99,82.99));
	locationMap.insert(getLocation("dallas",32.80,96.79));
	locationMap.insert(getLocation("dayton",39.76,84.20));
	locationMap.insert(getLocation("daytonaBeach",29.21,81.04));
	locationMap.insert(getLocation("denver",39.73,104.97));
	locationMap.insert(getLocation("desMoines",41.59,93.62));
	locationMap.insert(getLocation("elPaso",31.79,106.42));
	locationMap.insert(getLocation("eugene",44.06,123.11));
	locationMap.insert(getLocation("europe",48.87,-2.33));
	locationMap.insert(getLocation("ftWorth",32.74,97.33));
	locationMap.insert(getLocation("fresno",36.78,119.79));
	locationMap.insert(getLocation("grandJunction",39.08,108.56));
	locationMap.insert(getLocation("greenBay",44.51,88.02));
	locationMap.insert(getLocation("greensboro",36.08,79.82));
	locationMap.insert(getLocation("houston",29.76,95.38));
	locationMap.insert(getLocation("indianapolis",39.79,86.15));
	locationMap.insert(getLocation("jacksonville",30.32,81.66));
	locationMap.insert(getLocation("japan",35.68,220.23));
	locationMap.insert(getLocation("kansasCity",39.08,94.56));
	locationMap.insert(getLocation("keyWest",24.56,81.78));
	locationMap.insert(getLocation("lafayette",30.21,92.03));
	locationMap.insert(getLocation("lakeCity",30.19,82.64));
	locationMap.insert(getLocation("laredo",27.52,99.49));
	locationMap.insert(getLocation("lasVegas",36.19,115.22));
	locationMap.insert(getLocation("lincoln",40.81,96.68));
	locationMap.insert(getLocation("littleRock",34.74,92.33));
	locationMap.insert(getLocation("losAngeles",34.03,118.17));
	locationMap.insert(getLocation("macon",32.83,83.65));
	locationMap.insert(getLocation("medford",42.33,122.86));
	locationMap.insert(getLocation("memphis",35.12,89.97));
	locationMap.insert(getLocation("mexia",31.68,96.48));
	locationMap.insert(getLocation("mexico",19.40,99.12));
	locationMap.insert(getLocation("miami",25.79,80.22));
	locationMap.insert(getLocation("midland",43.62,84.23));
	locationMap.insert(getLocation("milwaukee",43.05,87.96));
	locationMap.insert(getLocation("minneapolis",44.96,93.27));
	locationMap.insert(getLocation("modesto",37.66,120.99));
	locationMap.insert(getLocation("montreal",45.50,73.67));
	locationMap.insert(getLocation("nashville",36.15,86.76));
	locationMap.insert(getLocation("newHaven",41.31,72.92));
	locationMap.insert(getLocation("newOrleans",29.97,90.06));
	locationMap.insert(getLocation("newYork",40.70,73.92));
	locationMap.insert(getLocation("norfolk",36.89,76.26));
	locationMap.insert(getLocation("oakland",37.80,122.23));
	locationMap.insert(getLocation("oklahomaCity",35.48,97.53));
	locationMap.insert(getLocation("omaha",41.26,96.01));
	locationMap.insert(getLocation("orlando",28.53,81.38));
	locationMap.insert(getLocation("ottawa",45.42,75.69));
	locationMap.insert(getLocation("pensacola",30.44,87.21));
	locationMap.insert(getLocation("philadelphia",40.72,76.12));
	locationMap.insert(getLocation("phoenix",33.53,112.08));
	locationMap.insert(getLocation("pittsburgh",40.40,79.84));
	locationMap.insert(getLocation("pointReyes",38.07,122.81));
	locationMap.insert(getLocation("portland",45.52,122.64));
	locationMap.insert(getLocation("providence",41.80,71.36));
	locationMap.insert(getLocation("provo",40.24,111.66));
	locationMap.insert(getLocation("raleigh",35.82,78.64));
	locationMap.insert(getLocation("redding",40.58,122.37));
	locationMap.insert(getLocation("reno",39.53,119.82));
	locationMap.insert(getLocation("richmond",37.54,77.46));
	locationMap.insert(getLocation("rochester",43.17,77.61));
	locationMap.insert(getLocation("sacramento",38.56,121.47));
	locationMap.insert(getLocation("salem",44.93,123.03));
	locationMap.insert(getLocation("salinas",36.68,121.64));
	locationMap.insert(getLocation("saltLakeCity",40.75,111.89));
	locationMap.insert(getLocation("sanAntonio",29.45,98.51));
	locationMap.insert(getLocation("sanDiego",32.78,117.15));
	locationMap.insert(getLocation("sanFrancisco",37.76,122.44));
	locationMap.insert(getLocation("sanJose",37.30,121.87));
	locationMap.insert(getLocation("sanLuisObispo",35.27,120.66));
	locationMap.insert(getLocation("santaFe",35.67,105.96));
	locationMap.insert(getLocation("saultSteMarie",46.49,84.35));
	locationMap.insert(getLocation("savannah",32.05,81.10));
	locationMap.insert(getLocation("seattle",47.63,122.33));
	locationMap.insert(getLocation("stLouis",38.63,90.24));
	locationMap.insert(getLocation("stamford",41.07,73.54));
	locationMap.insert(getLocation("stockton",37.98,121.30));
	locationMap.insert(getLocation("tallahassee",30.45,84.27));
	locationMap.insert(getLocation("tampa",27.97,82.46));
	locationMap.insert(getLocation("thunderBay",48.38,89.25));
	locationMap.insert(getLocation("toledo",41.67,83.58));
	locationMap.insert(getLocation("toronto",43.65,79.38));
	locationMap.insert(getLocation("tucson",32.21,110.92));
	locationMap.insert(getLocation("tulsa",36.13,95.94));
	locationMap.insert(getLocation("uk1",51.30,0.00));
	locationMap.insert(getLocation("uk2",51.30,0.00));
	locationMap.insert(getLocation("vancouver",49.25,123.10));
	locationMap.insert(getLocation("washington",38.91,77.01));
	locationMap.insert(getLocation("westPalmBeach",26.71,80.05));
	locationMap.insert(getLocation("wichita",37.69,97.34));
	locationMap.insert(getLocation("winnipeg",49.90,97.13));
	locationMap.insert(getLocation("yuma",32.69,114.62));
}

void initCityRoadMap()
{
	CityRoadMap.push_back(getEdgeStr("albanyNY", "montreal", 226));
	CityRoadMap.push_back(getEdgeStr("albanyNY", "boston", 166));
	CityRoadMap.push_back(getEdgeStr("albanyNY", "rochester", 148));
	CityRoadMap.push_back(getEdgeStr("albanyGA", "tallahassee", 120));
	CityRoadMap.push_back(getEdgeStr("albanyGA", "macon", 106));
	CityRoadMap.push_back(getEdgeStr("albuquerque", "elPaso", 267));
	CityRoadMap.push_back(getEdgeStr("albuquerque", "santaFe", 61));
	CityRoadMap.push_back(getEdgeStr("atlanta", "macon", 82));
	CityRoadMap.push_back(getEdgeStr("atlanta", "chattanooga", 117));
	CityRoadMap.push_back(getEdgeStr("augusta", "charlotte", 161));
	CityRoadMap.push_back(getEdgeStr("augusta", "savannah", 131));
	CityRoadMap.push_back(getEdgeStr("austin", "houston", 186));
	CityRoadMap.push_back(getEdgeStr("austin", "sanAntonio", 79));
	CityRoadMap.push_back(getEdgeStr("bakersfield", "losAngeles", 112)); 
	CityRoadMap.push_back(getEdgeStr("bakersfield", "fresno", 107));
	CityRoadMap.push_back(getEdgeStr("baltimore", "philadelphia", 102));
	CityRoadMap.push_back(getEdgeStr("baltimore", "washington", 45));
	CityRoadMap.push_back(getEdgeStr("batonRouge", "lafayette", 50));
	CityRoadMap.push_back(getEdgeStr("batonRouge", "newOrleans", 80));
	CityRoadMap.push_back(getEdgeStr("beaumont", "houston", 69));  
	CityRoadMap.push_back(getEdgeStr("beaumont", "lafayette", 122));
	CityRoadMap.push_back(getEdgeStr("boise", "saltLakeCity", 349)); 
	CityRoadMap.push_back(getEdgeStr("boise", "portland", 428));
	CityRoadMap.push_back(getEdgeStr("boston", "providence", 51));
	CityRoadMap.push_back(getEdgeStr("buffalo", "toronto", 105)); 
	CityRoadMap.push_back(getEdgeStr("buffalo", "rochester", 64));  
	CityRoadMap.push_back(getEdgeStr("buffalo", "cleveland", 191));
	CityRoadMap.push_back(getEdgeStr("buffalo", "toronto", 105)); 
	CityRoadMap.push_back(getEdgeStr("buffalo", "cleveland", 191));
	CityRoadMap.push_back(getEdgeStr("calgary", "vancouver", 605)); 
	CityRoadMap.push_back(getEdgeStr("calgary", "winnipeg", 829));
	CityRoadMap.push_back(getEdgeStr("charlotte", "greensboro",  91));
	CityRoadMap.push_back(getEdgeStr("chattanooga", "nashville",  129));
	CityRoadMap.push_back(getEdgeStr("chicago", "milwaukee",  90));  
	CityRoadMap.push_back(getEdgeStr("chicago", "midland",  279));
	CityRoadMap.push_back(getEdgeStr("cincinnati", "indianapolis",  110));  
	CityRoadMap.push_back(getEdgeStr("cincinnati", "dayton",  56));
	CityRoadMap.push_back(getEdgeStr("cleveland", "pittsburgh",  157));  
	CityRoadMap.push_back(getEdgeStr("cleveland", "columbus",  142));
	CityRoadMap.push_back(getEdgeStr("coloradoSprings", "denver",  70)); 
	CityRoadMap.push_back(getEdgeStr("coloradoSprings", "santaFe",  316));
	CityRoadMap.push_back(getEdgeStr("columbus", "dayton", 72));
	CityRoadMap.push_back(getEdgeStr("dallas", "denver", 792));  
	CityRoadMap.push_back(getEdgeStr("dallas", "mexia", 83));
	CityRoadMap.push_back(getEdgeStr("daytonaBeach", "jacksonville", 92));  
	CityRoadMap.push_back(getEdgeStr("daytonaBeach", "orlando",  54));
	CityRoadMap.push_back(getEdgeStr("denver", "wichita",  523));  
	CityRoadMap.push_back(getEdgeStr("denver", "grandJunction", 246));
	CityRoadMap.push_back(getEdgeStr("desMoines", "omaha", 135));  
	CityRoadMap.push_back(getEdgeStr("desMoines", "minneapolis", 246));
	CityRoadMap.push_back(getEdgeStr("elPaso", "sanAntonio", 580)); 
	CityRoadMap.push_back(getEdgeStr("elPaso", "tucson", 320));
	CityRoadMap.push_back(getEdgeStr("eugene", "salem", 63)); 
	CityRoadMap.push_back(getEdgeStr("eugene", "medford", 165));
	CityRoadMap.push_back(getEdgeStr("europe", "philadelphia", 3939));
	CityRoadMap.push_back(getEdgeStr("ftWorth", "oklahomaCity", 209));
	CityRoadMap.push_back(getEdgeStr("fresno", "modesto", 109));
	CityRoadMap.push_back(getEdgeStr("grandJunction", "provo", 220));
	CityRoadMap.push_back(getEdgeStr("greenBay", "minneapolis", 304));
	CityRoadMap.push_back(getEdgeStr("greenBay", "milwaukee", 117));
	CityRoadMap.push_back(getEdgeStr("greensboro", "raleigh", 74));
	CityRoadMap.push_back(getEdgeStr("houston", "mexia", 165));
	CityRoadMap.push_back(getEdgeStr("indianapolis", "stLouis", 246));
	CityRoadMap.push_back(getEdgeStr("jacksonville", "savannah", 140));
	CityRoadMap.push_back(getEdgeStr("jacksonville", "lakeCity", 113));
	CityRoadMap.push_back(getEdgeStr("japan", "pointReyes", 5131)); 
	CityRoadMap.push_back(getEdgeStr("japan", "sanLuisObispo", 5451));
	CityRoadMap.push_back(getEdgeStr("kansasCity", "tulsa", 249));  
	CityRoadMap.push_back(getEdgeStr("kansasCity", "stLouis", 256)); 
	CityRoadMap.push_back(getEdgeStr("kansasCity", "wichita", 190));
	CityRoadMap.push_back(getEdgeStr("keyWest", "tampa", 446));
	CityRoadMap.push_back(getEdgeStr("lakeCity", "tampa", 169));  
	CityRoadMap.push_back(getEdgeStr("lakeCity", "tallahassee", 104));
	CityRoadMap.push_back(getEdgeStr("laredo", "sanAntonio", 154));
	CityRoadMap.push_back(getEdgeStr("laredo", "mexico", 741));
	CityRoadMap.push_back(getEdgeStr("lasVegas", "losAngeles", 275)); 
	CityRoadMap.push_back(getEdgeStr("lasVegas", "saltLakeCity", 486));
	CityRoadMap.push_back(getEdgeStr("lincoln", "wichita", 277));
	CityRoadMap.push_back(getEdgeStr("lincoln", "omaha", 58));
	CityRoadMap.push_back(getEdgeStr("littleRock", "memphis", 137)); 
	CityRoadMap.push_back(getEdgeStr("littleRock", "tulsa", 276));
	CityRoadMap.push_back(getEdgeStr("losAngeles", "sanDiego", 124)); 
	CityRoadMap.push_back(getEdgeStr("losAngeles", "sanLuisObispo",  182));
	CityRoadMap.push_back(getEdgeStr("medford", "redding",  150));
	CityRoadMap.push_back(getEdgeStr("memphis",  "nashville",  210));
	CityRoadMap.push_back(getEdgeStr("miami",  "westPalmBeach",  67));
	CityRoadMap.push_back(getEdgeStr("midland",  "toledo",  82));
	CityRoadMap.push_back(getEdgeStr("minneapolis",  "winnipeg",  463));
	CityRoadMap.push_back(getEdgeStr("modesto",  "stockton",  29));
	CityRoadMap.push_back(getEdgeStr("montreal",  "ottawa",  132));
	CityRoadMap.push_back(getEdgeStr("newHaven",  "providence",  110));  
	CityRoadMap.push_back(getEdgeStr("newHaven",  "stamford",  92));
	CityRoadMap.push_back(getEdgeStr("newOrleans",  "pensacola",  268));
	CityRoadMap.push_back(getEdgeStr("newYork",  "philadelphia",  101));
	CityRoadMap.push_back(getEdgeStr("norfolk",  "richmond",  92));  
	CityRoadMap.push_back(getEdgeStr("norfolk",  "raleigh",  174));
	CityRoadMap.push_back(getEdgeStr("oakland",  "sanFrancisco",  8)); 
	CityRoadMap.push_back(getEdgeStr("oakland",  "sanJose",  42));
	CityRoadMap.push_back(getEdgeStr("oklahomaCity", "tulsa",  105));
	CityRoadMap.push_back(getEdgeStr("orlando", "westPalmBeach",  168)); 
	CityRoadMap.push_back(getEdgeStr("orlando", "tampa",  84));
	CityRoadMap.push_back(getEdgeStr("ottawa",  "toronto",  269));
	CityRoadMap.push_back(getEdgeStr("pensacola",  "tallahassee",  120));
	CityRoadMap.push_back(getEdgeStr("philadelphia",  "pittsburgh",  319));
	CityRoadMap.push_back(getEdgeStr("philadelphia",  "newYork",  101)); 
	CityRoadMap.push_back(getEdgeStr("philadelphia",  "uk1",  3548));
	CityRoadMap.push_back(getEdgeStr("philadelphia",  "uk2",  3548));
	CityRoadMap.push_back(getEdgeStr("phoenix",  "tucson",  117));  
	CityRoadMap.push_back(getEdgeStr("phoenix",  "yuma",  178));
	CityRoadMap.push_back(getEdgeStr("pointReyes",  "redding",  215)); 
	CityRoadMap.push_back(getEdgeStr("pointReyes",  "sacramento",  115));
	CityRoadMap.push_back(getEdgeStr("portland",  "seattle",  174));  
	CityRoadMap.push_back(getEdgeStr("portland",  "salem",  47));
	CityRoadMap.push_back(getEdgeStr("reno",  "saltLakeCity",  520)); 
	CityRoadMap.push_back(getEdgeStr("reno",  "sacramento",  133));
	CityRoadMap.push_back(getEdgeStr("richmond",  "washington",  105));
	CityRoadMap.push_back(getEdgeStr("sacramento",  "sanFrancisco",  95));  
	CityRoadMap.push_back(getEdgeStr("sacramento",  "stockton",  51));
	CityRoadMap.push_back(getEdgeStr("salinas",  "sanJose",  31));  
	CityRoadMap.push_back(getEdgeStr("salinas",  "sanLuisObispo",  137));
	CityRoadMap.push_back(getEdgeStr("sanDiego",  "yuma",  172));
	CityRoadMap.push_back(getEdgeStr("saultSteMarie", "thunderBay",  442));  
	CityRoadMap.push_back(getEdgeStr("saultSteMarie",  "toronto",  436));
	CityRoadMap.push_back(getEdgeStr("seattle",  "vancouver",  115));
	CityRoadMap.push_back(getEdgeStr("thunderBay",  "winnipeg",  440));
}

struct Node
{
	std::string cityName;
	bool visited;
	int dist;
	double heuristic;
	std::vector<std::pair<Node*,int> > adjacentNodes;
	Node *parent;
	Node(const std::string& city,bool isVisited):visited(isVisited),cityName(city),parent(0),dist(SENTINEL_VAL),heuristic(SENTINEL_VAL){} 
};

double heuristicDistance(const std::string& city1,const std::string& city2)
{
	std::map<std::string,Location>::const_iterator it1 = locationMap.find(city1);
	std::map<std::string,Location>::const_iterator it2 = locationMap.find(city2);
	if(it1 == locationMap.end() || it2 == locationMap.end())
	{
		std::cout<<"City name not found\n";
		exit(1);
	}
	double latitude1 = it1->second.latitude;
	double longitude1 = it1->second.longitude;
	double latitude2 = it2->second.latitude;
	double longitude2 = it2->second.longitude;

	double latSum = latitude1 + latitude2;
	double latSub = latitude1 - latitude2;
	double longSub = longitude1 - longitude2;
	
	double temp1 = pow(69.5 * latSub, 2);
	double temp2 = pow(69.5 * cos(latSum / 360 * PI_VAL) * longSub, 2); 
	double heuristicDist = sqrt(temp1 + temp2);
	return heuristicDist;
}

Node* getNode(std::map<std::string,Node*> &RoadMap,const std::string &city)
{
	std::map<std::string,Node*>::iterator it = RoadMap.lower_bound(city);
	if(it != RoadMap.end() && !(RoadMap.key_comp()(city, it->first)))
	{
		return it->second;
	}
	else
	{
		Node *node = new Node(city,false);
		RoadMap.insert(it,std::map<std::string,Node*>::value_type(city, node));    
		return node;
	}
}

Node* findNode(std::map<std::string,Node*> &RoadMap,const std::string &city)
{
	std::map<std::string,Node*>::iterator it = RoadMap.find(city);
	if(it == RoadMap.end())
	{
		return 0;
	}
	else
	{
		return it->second;
	}
}


void createGraph(std::map<std::string,Node*> &RoadMap)
{
	int edges = CityRoadMap.size();	
	for(int i = 0;i < edges; ++i)
	{
		std::stringstream ss;
		ss<<CityRoadMap[i];
		std::string city1,city2;
		ss>>city1;
		ss>>city2;
		int dist;
		ss>>dist;
		Node *city1Node = getNode(RoadMap,city1);
		Node *city2Node = getNode(RoadMap,city2);
		city1Node->adjacentNodes.push_back(std::make_pair(city2Node,dist));
		city2Node->adjacentNodes.push_back(std::make_pair(city1Node,dist));
	}
}

//void printGraph(std::map<std::string,Node*> &RoadMap)
//{
//	std::map<std::string,Node*>::const_iterator it = RoadMap.begin();
//	for(; it != RoadMap.end(); ++it)
//	{
//		std::cout<<it->first<<":";
//		std::vector<Node*> nodes = (it->second)->adjacentNodes;
//		std::vector<Node*>::iterator vit = nodes.begin();
//		for(; vit != nodes.end(); ++vit)
//		{
//			std::cout<<(*vit)->cityName<<",";
//		}
//		std::cout<<nodes.size()<<"\n";
//	}
//}

void printPath(Node* node,int& count)
{
	if(node)
	{
		printPath(node->parent,count);
		if(node->parent)
		{
			std::cout<<",";
		}
		++count;
		std::cout<<node->cityName;
	}
}

void printReport(Node* node,std::vector<Node*> expandedNodes)
{
	std::cout<<"A comma separated list of expanded nodes (the closed list) : ";
	for(unsigned int i = 0;i < expandedNodes.size();++i)
	{
		if(i == 0)
		{
			std::cout<<expandedNodes[i]->cityName;
		}
		else
		{
			std::cout<<","<<expandedNodes[i]->cityName;
		}
	}
	std::cout<<"\nThe number of nodes expanded : "<<expandedNodes.size();
	std::cout<<"\nA comma-separated list of nodes in the solution path : ";
	int count = 0;
	printPath(node,count);
	std::cout<<"\nThe number of nodes in the path : "<<count;
	std::cout<<"\nThe total distance from A to B in the solution path : "<<node->dist;
}

struct greaterThan
{
	bool operator()(const Node* node1, const Node* node2)
	{
		return std::greater<int>()(node1->dist,node2->dist);
	}
};

struct greaterThanHeuristic
{
	bool operator()(const Node* node1, const Node* node2)
	{
		return std::greater<double>()(node1->heuristic,node2->heuristic);
	}
};

struct greaterThanAstar
{
	bool operator()(const Node* node1, const Node* node2)
	{
		double astarDist1 = node1->heuristic + (double)node1->dist;
		double astarDist2 = node2->heuristic + (double)node2->dist;
		return std::greater<double>()(astarDist1,astarDist2);
	}
};

std::vector<std::pair<Node*,int> > moveGenerator(Node *parent)
{
	std::vector<std::pair<Node*,int> > temp = parent->adjacentNodes;
	return temp;
}

bool uniform(std::map<std::string,Node*> &RoadMap,const std::string &source,const std::string &goal)
{
	std::priority_queue<Node*,std::vector<Node*>, greaterThan > uniformQueue;
	std::vector<Node*> expandedNodes;
	Node* sourceNode = findNode(RoadMap,source);
	if(!sourceNode)
	{
		std::cout<<"Start City name not found\n";
		return false;
	}
	sourceNode->dist = 0;
	uniformQueue.push(sourceNode);
	while(!uniformQueue.empty())
	{
		Node* topNode = uniformQueue.top();
		uniformQueue.pop();//expanded
		/*Do Goal Match*/
		if(topNode->cityName == goal)
		{
			printReport(topNode,expandedNodes);
			return true;
		}
		expandedNodes.push_back(topNode);
		topNode->visited = true;
		std::vector<std::pair<Node*,int> > adjacentNodes = moveGenerator(topNode);//replace with move generator
		std::vector<std::pair<Node*,int> >::iterator vit = adjacentNodes.begin();
		for(; vit != adjacentNodes.end(); ++vit)
		{
			if(!vit->first->visited)
			{
				if((vit->first->dist) > (topNode->dist + vit->second))
				{
					vit->first->dist = topNode->dist + vit->second;
					vit->first->parent = topNode;
					uniformQueue.push(vit->first);
				}
			}
		}
	}
	//not found
	std::cout<<"Destination City name not found\n";
	return false;
}

bool greedy(std::map<std::string,Node*> &RoadMap,const std::string &source,const std::string &goal)
{
	std::priority_queue<Node*,std::vector<Node*>, greaterThanHeuristic > greedyQueue;
	std::vector<Node*> expandedNodes;
	Node* sourceNode = findNode(RoadMap,source);
	if(!sourceNode)
	{
		std::cout<<"Start City name not found\n";
		return false;
	}
	sourceNode->dist = 0;
	sourceNode->heuristic = heuristicDistance(sourceNode->cityName,goal);
	greedyQueue.push(sourceNode);
	while(!greedyQueue.empty())
	{
		Node* topNode = greedyQueue.top();
		greedyQueue.pop();//expanded
		/*Do Goal Match*/
		if(topNode->cityName == goal)
		{
			printReport(topNode,expandedNodes);
			return true;
		}
		expandedNodes.push_back(topNode);
		topNode->visited = true;
		std::vector<std::pair<Node*,int> > adjacentNodes = moveGenerator(topNode);//replace with move generator
		std::vector<std::pair<Node*,int> >::iterator vit = adjacentNodes.begin();
		for(; vit != adjacentNodes.end(); ++vit)
		{
			if(!vit->first->visited)
			{
				vit->first->heuristic = heuristicDistance(vit->first->cityName,goal);
				vit->first->dist = topNode->dist + vit->second;
				vit->first->parent = topNode;
				greedyQueue.push(vit->first);
			}
		}
	}
	//not found
	std::cout<<"Destination City name not found\n";
	return false;
}

bool astar(std::map<std::string,Node*> &RoadMap,const std::string &source,const std::string &goal)
{
	std::priority_queue<Node*,std::vector<Node*>, greaterThanAstar > astarQueue;
	std::vector<Node*> expandedNodes;
	Node* sourceNode = findNode(RoadMap,source);
	if(!sourceNode)
	{
		std::cout<<"Start City name not found\n";
		return false;
	}
	sourceNode->dist = 0;
	sourceNode->heuristic = heuristicDistance(sourceNode->cityName,goal);
	astarQueue.push(sourceNode);
	while(!astarQueue.empty())
	{
		Node* topNode = astarQueue.top();
		astarQueue.pop();//expanded
		/*Do Goal Match*/
		if(topNode->cityName == goal)
		{
			printReport(topNode,expandedNodes);
			return true;
		}
		expandedNodes.push_back(topNode);
		topNode->visited = true;
		std::vector<std::pair<Node*,int> > adjacentNodes = moveGenerator(topNode);//replace with move generator
		std::vector<std::pair<Node*,int> >::iterator vit = adjacentNodes.begin();
		for(; vit != adjacentNodes.end(); ++vit)
		{
			if(!vit->first->visited)
			{
				vit->first->heuristic = heuristicDistance(vit->first->cityName,goal);
				vit->first->dist = topNode->dist + vit->second;
				vit->first->parent = topNode;
				astarQueue.push(vit->first);
			}
		}
	}
	//not found
	std::cout<<"Destination City name not found\n";
	return false;
}

int main(int argc, char* argv[])
{
	
	if (argc < 4) 
	{
		std::cout << "Usage : ./a.out [greedy|uniform|astar] [start] [destination]\n";
		return 1;
	} 
	int choice = 0;
	if (strcmp(argv[1], "greedy")==0) 
	{
		choice = 1;
    } 
	else if (strcmp(argv[1], "uniform")==0) 
	{  
		choice = 2;
    }
	else if (strcmp(argv[1], "astar")==0) 
	{  
		choice = 3;
    }
	else
	{
		std::cout << "Unknown Search Type\n";
		std::cout << "Usage : ./a.out [greedy|uniform|astar] [start] [destination]\n";
		return 1;
	}
	initCityRoadMap();
	initLocations();
	std::map<std::string,Node*> RoadMap;
	createGraph(RoadMap);
	std::string startCity = argv[2];
	std::string destinationCity = argv[3];
	std::cout << "\n";
	switch(choice)
	{
	case 1:
		greedy(RoadMap,startCity,destinationCity);
		break;
	case 2:
		uniform(RoadMap,startCity,destinationCity);
		break;
	case 3:
		astar(RoadMap,startCity,destinationCity);
		break;
	}
	std::cout << "\n";
	return 0;
}

